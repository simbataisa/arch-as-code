# Brand material — https://techcombank.com/

- site name: Techcombank
- title: Techcombank - Ngân hàng TMCP Kỹ thương Việt Nam | Techcombank
- description: Đặt khách hàng là trọng tâm, Techcombank sẵn sàng cùng bạn nâng tầm giá trị sống vượt trội. Khám phá ngay các dịch vụ từ ngân hàng số hàng đầu cho khách hàng.

## Measured colors (frequency-ranked from the site's actual CSS)

- `#ed1c24` ×75 — css-var:--pink-red; css-var:--accent selector::root; prop:color selector:.header_layout .navigation-primary_left .navigation-primary_item.active
- `#ed1b24` ×40 — css-var:--primary-red; prop:border selector:.header-popup-content .radio-btn .radio label::before; prop:background selector:.header-popup-content .radio-btn .radio input:checked ~ label::after
- `#d9d9d9` ×16 — css-var:--cta-disabled; prop:background-color selector:.scroll-to-top .scroll-to-top__icon; prop:background-color selector:.currency-converter .currency-selector__currency-item.not-found .exchange-section__input
- `#404040` ×6 — css-var:--cta-secondary; css-var:--secondary-gray selector::root; prop:border selector:.insurance-calculation .panel-info__content-button a
- `#e3e4e5` ×2 — prop:border selector:.offer-listing .btn-open-filter, .offer-listing-promotions .btn-open-filter; css-var:--primary-color-gray-500 selector::root
- `#d6b973` ×1 — css-var:--primary-gold
- `#1b1564` ×1 — css-var:--primary-navy-blue
- `#d6ebec` ×1 — css-var:--primary-sky-grey
- `#616161` ×111 — css-var:--secondary-grey-60; css-var:--gray-600 selector::root; css-var:--light-secondary-text selector::root
- `#a2a2a2` ×93 — css-var:--secondary-mid-grey-100; prop:color selector:.divider--dotted; prop:color selector:.header_layout .navigation-primary_left .navigation-primary_item
- `#e3e4e6` ×49 — css-var:--secondary-light-grey-100; prop:color selector:.light-gray; prop:border-right selector:.navigation_tab_title
- `#dedede` ×45 — css-var:--secondary-mid-grey-60; css-var:--light-background-hover selector::root; css-var:--light-border selector::root
- `#333333` ×32 — prop:border-color selector:.cmp-search__loading-indicator; css-var:--secondary-grey-80; prop:background selector:.dark-gray-bg
- `#c4c4c4` ×29 — prop:background-color selector:.header_layout .hambuger-icon span; prop:background selector:.list-item-document-download__body .slick-arrow; prop:background-color selector:.tab-vertical-qa__button::before
- `#444746` ×20 — prop:color selector:x; prop:border-color selector:x
- `#c5c5c5` ×19 — css-var:--secondary-mid-grey-80; prop:color selector:.dark-gray; prop:border-left selector:.header_layout .navigation-primary_left .navigation-primary_item.discover_dropdown_btn
- `#cccccc` ×18 — prop:border-color selector:.cmp-search__loading-indicator; prop:border selector:.cmp-search__results; prop:background-color selector:.cmp-search__item--is-focused
- `#808080` ×18 — prop:background selector:.ripple-btn-tab-vertical; prop:border-bottom selector:.faq-panel .faq-panel-container .answer-question; prop:border-bottom selector:.enhancedfaqpanel .enhancedfaq
- `#3366cc` ×16 — prop:color selector:.gsst_a:hover .gscb_a, .gsst_a:focus .gscb_a; prop:color selector:#gssb_b; prop:color selector:#gssb_b:hover
- `#212121` ×14 — css-var:--secondary-grey-100; css-var:--gray-900 selector::root; prop:background-color selector:.header-popup-content .form-content button
- `#000000` ×1210 (near-white/black) — prop:background-color selector:.cmp-carousel__indicator; prop:background-color selector:.cmp-carousel__indicator--active; css-var:--primary-black
- `#ffffff` ×752 (near-white/black) — prop:background selector:.cmp-search__results; css-var:--primary-white; prop:color selector:.dark a
- `#f5f6f8` ×30 (near-white/black) — css-var:--secondary-mid-grey-40; css-var:--background-magenta; prop:background selector:body, html
- `#f5f5f5` ×13 (near-white/black) — css-var:--secondary-light-grey-60; prop:border-left selector:.header_layout .hambuger-icon; prop:background-color selector:.colunm-information__content

## Measured fonts (frequency-ranked font-family declarations)

- SF Pro Display ×470
- Roboto ×6
- SFProDisplay ×3
- SF Pro Display Italic ×1

@font-face families: SF Pro Display

## Logo candidates (downloaded into ./logos/)

(none downloadable)

## Copy harvested from the site (for voice & tone analysis)

### Headings

- Chào mừng bạn đến với Techcombank
- Khách hàng cá nhân
- Hộ kinh doanh
- Doanh nghiệp vừa và nhỏ
- Doanh nghiệp lớn và định chế tài chính
- Nhà đầu tư
- Về chúng tôi
- Phát triển bền vững
- Liên hệ
- Tỷ giá hối đoái

### Nav labels

Công cụ & Tiện ích · Hỗ trợ · Liên hệ · Tiếng Việt · English
