# Applied UI kit

`index.html` is a compact, source-backed service-finder reference, not a claim of access to a private banking application. It composes captured public-site patterns: a white global header, red selected navigation, customer-segment routes, light architectural hero imagery, SF Pro Display, 8px corners, and 1px pale-grey rules.

## Structure

- `index.html` — runnable public-web reference.
- `../../colors_and_type.css` — token and typography source.
- `../../logos/` and `../../imagery/` — preserved assets used directly by the reference.

## Component files

The reference is intentionally a single small HTML composition because the source evidence is a public marketing page rather than a captured application codebase. Its reusable modules are the header/navigation, hero, and customer-route cards, all labelled with stable `data-od-id` attributes. There are no `components/` source files: inventing an `App`, `Sidebar`, or `ChatArea` module would incorrectly imply evidence for a private application interface. The entry itself is the composed application reference.

## Usage workflow

Open the entry in a browser, identify the needed module, then copy only that module’s semantic structure into a confirmed Techcombank service. Load the shared CSS first and use preserved source assets rather than redrawing identity elements.

## Design notes

Keep the white-led hierarchy, SF Pro Display type, 8px corners, 1px pale-grey rules, and red selection budget. Reflow at about 1024px instead of shrinking desktop navigation into a narrow viewport.

## Source basis

The header arrangement, customer segmentation, colour roles, font family, spacing, and hero posture were measured from the preserved homepage and stylesheet capture. The sample intentionally avoids representing private banking workflows not visible in the public evidence.
