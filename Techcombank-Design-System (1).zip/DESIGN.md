---
name: "Techcombank"
category: Brands
surface: web
colors:
  primary-white: "#ffffff"
  mist-grey: "#f5f6f8"
  ink: "#212121"
  secondary-grey: "#616161"
  light-border: "#dedede"
  pink-red: "#ed1c24"
  primary-red: "#ed1b24"
---

# Techcombank

> Category: Brands

> Surface: web

*Chào mừng bạn đến với Techcombank*

Đặt khách hàng là trọng tâm, Techcombank sẵn sàng cùng bạn nâng tầm giá trị sống vượt trội. Khám phá ngay các dịch vụ từ ngân hàng số hàng đầu cho khách hàng.

## Color Palette

| Role | Name | Hex | Usage |
| --- | --- | --- | --- |
| background | Primary white | `#ffffff` | primary navigation, cards, controls, and light content surfaces |
| surface | Mist grey | `#f5f6f8` | page canvas, soft section bands, and quiet hover surfaces |
| foreground | Ink | `#212121` | primary text, strong navigation, and dark controls |
| muted | Secondary grey | `#616161` | secondary copy, descriptions, and subdued UI text |
| border | Light border | `#dedede` | dividers, field outlines, tab rules, and subtle card separation |
| accent | Pink red | `#ed1c24` | brand emphasis, active navigation, selections, progress, and red highlights |
| accent-secondary | Primary red | `#ed1b24` | brand actions, checked states, and interactive red details |

## Typography
- **Display:** SF Pro Display — weights 300, 400, 500, 600, 700, 800 — fallbacks: system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif
- **Body:** SF Pro Display — weights 300, 400, 500, 600, 700, 800 — fallbacks: system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif

## Voice & Tone

- **Adjectives:** customer-centred, confident, clear, practical, forward-looking
- **Tone:** Clear, encouraging Vietnamese banking language that leads with the customer, then names a concrete audience, service, or action. It balances institutional assurance with direct everyday guidance.

### Messaging pillars
- Chào mừng bạn đến với Techcombank
- Khách hàng cá nhân
- Hộ kinh doanh

### Vocabulary
- **Use:** nâng tầm giá trị sống, ngân hàng số, khách hàng cá nhân, hộ kinh doanh, doanh nghiệp vừa và nhỏ, tỷ giá hối đoái, phát triển bền vững
- **Avoid:** unqualified superlatives, opaque financial jargon without a customer benefit, generic technology hype

## Imagery

- **Style:** High-key, polished banking imagery with pale sky-blue fields, architectural transparency, disciplined white space, and small red brand moments.
- **Subjects:** Techcombank architecture and urban scale, customer-life and product-card imagery, award and trust signals, digital service moments
- **Treatment:** Use full-bleed cover imagery with ample negative space for copy. Keep the image light and documentary or product-led; use red only as a small signal rather than a wash.
- **Avoid:** generic stock trading screens, unbranded neon-fintech gradients, dense decorative icon mosaics, large unmodulated red fields behind body copy

## Layout

- **Radius:** 8px
- **Border weight:** 1px
- **Spacing:** 8px baseline with 8px, 16px, 24px, and 40px as recurring control, navigation, card, and hero increments

### Posture rules
- Use a bright, white-led content surface over very light grey page bands; reserve black for strong calls to action and high-contrast modules.
- Keep component corners at 8px and use 1px pale-grey rules before adding heavy elevation.
- Set large display copy light (300) and roomy; use 600–700 for action labels, navigation, and card titles.
- Use compact inline navigation at desktop with 24px item separation; collapse the navigation around the source's 1024px threshold.
- Signal active or selected states with the red accent, a small underline/marker, or a red progress detail—not broad red fills.
- Pair large imagery with a contained dark or white information panel; keep hero copy aligned to a deliberate content edge.
