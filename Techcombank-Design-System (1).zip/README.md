# Techcombank Design System

## Product Overview

This source-backed package captures the public web language of Techcombank: customer-led digital banking, compact navigation, a white and mist-grey interface, SF Pro Display typography, and restrained red activation. Source: `https://techcombank.com/`.

Its primary web surfaces are a global header, customer-segment entry points, service cards, exchange-rate utilities, forms, and editorial/award hero content. The reusable package is for clear product routing, financial-information density, and trustworthy calls to action.

**Source product:** Techcombank public digital-banking website.  
**Primary surfaces:** navigation, audience routing, product/service cards, tools, forms, editorial heroes.  
**Core capabilities:** route customers by need, make product information scannable, communicate trust, and provide clear calls to action.

## Product Context

Techcombank’s public site uses audience-specific pathways for personal customers, household businesses, SMEs, larger businesses, investors, and corporate content. The system translates that model into a bright, service-oriented interface: prominent navigation, specific product routes, contained information modules, and visual trust markers.

## Source Context

- `context/source-context.md` — source-evidence contract.
- `prefetch/page.html` and `prefetch/styles.css` — preserved homepage and CSS capture.
- `prefetch/material.md` — colour and typography measurements.

## Package contents

- `DESIGN.md` — canonical rules for new work.
- `BRAND.md` — concise identity, voice, imagery, and layout guide.
- `brand.json` — validated extraction manifest with asset inventory.
- `colors_and_type.css` — reusable local font faces and CSS tokens.
- `assets/techcombank_logo_svg_86201e50d1.svg`, `logos/techcombank-wordmark.svg`, `imagery/home-hero.webp`, and `fonts/SF-Pro-Display-Regular.woff2` — preserved source assets.
- `build/` — no source runtime build assets were present in the capture; this absence is intentional and recorded rather than fabricated.
- `source_examples/` — no substantive source-component snapshot was available from the public-page capture.
- `preview/` — six focused review cards.
- `ui_kits/app/` — applied source-backed interface reference.
- `system/` — regenerated token sets, component kits, and artifacts.

## Preview manifest

- `brand.html` — registered-system overview.
- `system/index.html` — complete gallery and live component preview.
- `system/kit.html` and `system/kit.dark.html` — light and dark component kits.
- `system/artifacts/{landing,deck,poster,email,newsletter,form}.html` — generated reusable deliverables.
- `preview/colors-primary.html`, `preview/typography-specimens.html`, `preview/spacing-tokens.html`, `preview/radius-and-rules.html`, `preview/components-buttons.html`, `preview/brand-assets.html` — focused evidence cards.

## Reuse Workflow

Read `DESIGN.md`, load `colors_and_type.css`, then use real files in `logos/` and `imagery/`. Prioritise white surfaces, 8px corners, 1px rules, 8px spacing increments, and a small red activation budget. Do not substitute a generic dark fintech treatment for the measured public-web direction.

Start any review in `preview/`, then use `ui_kits/app/index.html` as an applied implementation reference.

For reuse, inspect `preview/`, copy only confirmed patterns from `ui_kits/app/`, load `colors_and_type.css`, and use preserved `assets/`, `fonts/`, and image files rather than redrawing them.

### Review workflow

1. Check palette, typography, spacing, component, and real-asset cards under `preview/`.
2. Open `ui_kits/app/index.html` for composition and responsive behavior.
3. Verify new work against `DESIGN.md`, then use preserved files in `assets/`, `logos/`, `imagery/`, and `fonts/`.
