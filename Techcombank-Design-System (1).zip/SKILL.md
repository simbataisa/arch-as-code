---
name: techcombank-design-system
description: Apply the source-backed Techcombank visual system to web and presentation artifacts.
user-invocable: true
---

# Techcombank design system

## What is inside

`DESIGN.md` is the authoritative direction; `BRAND.md` adds brand rationale; `colors_and_type.css` exposes local SF Pro Display and tokens; `logos/`, `imagery/`, and `fonts/` preserve source assets. `preview/` carries focused review cards, `ui_kits/app/` carries the applied public-web reference, and `system/` contains the generated kits and six artifact examples. No `build/` or `source_examples/` evidence was available in the public source capture.

## Source context

The package is grounded in `https://techcombank.com/`, its captured homepage and CSS, and direct source-served assets. Refer to `context/source-context.md` and `prefetch/material.md` for measurement provenance.

## When to use this skill

Use for Techcombank-facing banking websites, service journeys, campaign pages, customer tools, slides, and other design artifacts that need to align with the public visual language.

## How to use

1. Read `README.md` and `DESIGN.md`.
2. Load `colors_and_type.css` before creating new components.
3. Use the logo and image files from `logos/` and `imagery/`, not reconstructed marks.
4. Review the relevant `preview/` card and `ui_kits/app/index.html` before adapting a pattern.
5. Review `system/kit.html` and the relevant file under `system/artifacts/` for generated examples.

## Design System Highlights

Build a white-led, precise hierarchy with `SF Pro Display` typography, 8px radius, an 8px spacing rhythm, thin pale-grey rules, and red only for active or branded signals. Keep copy customer-led and specific; preserve the source's bright architectural or product-led image posture.
