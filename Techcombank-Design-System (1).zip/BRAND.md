# Techcombank Brand Guide

## Provenance

This guide refines the existing extraction from `https://techcombank.com/` using the captured homepage, live source response, linked CSS, source-served logo assets, five SF Pro Display font files, and six image samples on 15 August 2026.

## Identity

Use the full horizontal wordmark at `logos/techcombank-wordmark.svg` by default. Its red double-diamond device is paired with a deep navy wordmark. For exact page-header fidelity, use `logos/techcombank-header.svg`; use the compact mobile mark only where horizontal space is genuinely constrained.

## Color

The operational palette is white, mist grey, ink, secondary grey, light border, and two closely related brand reds. Red is a navigation, selection, progress, or emphasis signal. It should not become an all-over background.

| Token | Value | Intent |
| --- | --- | --- |
| `--tcb-bg` | `#ffffff` | clean content and navigation surfaces |
| `--tcb-surface` | `#f5f6f8` | quiet canvas and section bands |
| `--tcb-fg` | `#212121` | primary ink and dark actions |
| `--tcb-muted` | `#616161` | explanatory text |
| `--tcb-border` | `#dedede` | thin structural rules |
| `--tcb-accent` | `#ed1c24` | branded activation |
| `--tcb-accent-secondary` | `#ed1b24` | checked and interactive detail |

## Type

Use the preserved `SF Pro Display` files through `colors_and_type.css`. Make hero and section display copy airy with a 300 weight; move to 600–700 only for labels, navigation, and actions.

## Voice

Be clear, customer-centred, practical, and quietly confident. Start with the person, business, or financial task; follow with a real service or action. Prefer source vocabulary such as *ngân hàng số*, *khách hàng cá nhân*, *hộ kinh doanh*, *doanh nghiệp vừa và nhỏ*, and *phát triển bền vững*.

## Imagery

Favour luminous architecture, urban scale, product or customer scenes, and earned trust markers. Keep composition spacious enough to carry copy, and use the supplied `imagery/` samples as the visual baseline. Avoid unrelated trading screens, decorative icon walls, and unbranded neon-fintech treatments.

## Layout

Use 8px corners, 1px light rules, and 8/16/24/40px spacing increments. Maintain a white-led hierarchy with mist-grey bands. At desktop, use compact inline navigation and red active states; reorganise around 1024px rather than squeezing the full nav.
